// 诊断脚本：连上调试版 Chrome，打印 Gemini 页面里各种候选选择器的命中情况。
// 用法: node tools/inspect-gemini.mjs
import { CDP, listTargets } from '../lib/cdp.mjs';

const port = Number(process.env.CDP_PORT || 9222);
const targets = await listTargets(port);
const pages = targets.filter((t) => t.type === 'page');
console.log('== 页面列表 ==');
for (const p of pages) console.log(' -', p.id, '|', p.title, '|', p.url);

const page = pages.find((p) => (p.url || '').includes('gemini.google.com')) || pages[0];
if (!page) { console.error('没有可用标签页'); process.exit(1); }

const cdp = await new CDP(page.webSocketDebuggerUrl).connect();
await cdp.send('Runtime.enable');

const report = await cdp.eval('(function(){' +
  'var sels=[' +
  "'rich-textarea .ql-editor[contenteditable=\"true\"]'," +
  "'rich-textarea div[contenteditable=\"true\"]'," +
  "'div[contenteditable=\"true\"][role=\"textbox\"]'," +
  "'button.send-button'," +
  "'button[aria-label*=\"Send\"]'," +
  "'model-response'," +
  "'message-content'," +
  "'stop-button'," +
  "'.markdown'" +
  '];' +
  'var out={url:location.href,title:document.title,hits:{}};' +
  'for(var i=0;i<sels.length;i++){out.hits[sels[i]]=document.querySelectorAll(sels[i]).length;}' +
  'var rs=document.querySelectorAll("model-response");' +
  'out.lastResponseText=rs.length?(rs[rs.length-1].innerText||"").slice(0,400):null;' +
  'return out;})()');

console.log('\n== 选择器命中 ==');
for (const [k, v] of Object.entries(report.hits || {})) console.log(' ' + (v ? 'OK ' : '-- ') + v + '  ' + k);
console.log('\nURL:', report.url);
console.log('标题:', report.title);
console.log('\n最后一条回答（截断）:\n' + (report.lastResponseText || '(无)'));
cdp.close();
