# Gemini Web Bridge · SillyTavern 服务端插件

让 SillyTavern 通过本机已登录 Chrome 中的 Gemini 网页会话生成回复。插件随酒馆启动、退出时清理连接和请求，不再需要单独运行桥接进程。

## 安装

要求：**运行酒馆的 Node.js 为 22+**，Chrome 与酒馆在同一台机器上。插件运行时没有第三方 npm 依赖。

1. 将完整插件目录放入酒馆安装目录的 `plugins/gemini-web-bridge/`，目录内应直接包含 `package.json`、`index.mjs`、`config.json`、`lib/` 和 `backends/`。
2. 修改**酒馆根目录**的 `config.yaml`：

   ```yaml
   enableServerPlugins: true
   ```

3. 双击插件目录中的 `start-chrome-debug.bat`。首次需在打开的独立 Chrome 中登录 Google，确认 Gemini 可以正常对话，并保持窗口开启。
4. 启动或重启酒馆。终端应出现：

   ```text
   [gemini-web-bridge] 监听 http://127.0.0.1:8788
   [gemini-web-bridge] 酒馆里填: 自定义地址 = http://127.0.0.1:8788/v1
   ```

这是 **SillyTavern 服务端插件**，放入 `plugins/`；网页“扩展 → 安装扩展”用于前端扩展，不能用于安装本插件。加载方式依照 [SillyTavern 官方服务端插件文档](https://docs.sillytavern.app/for-contributors/server-plugins/)。

## 在酒馆中连接

打开“API 连接”，选择“聊天补全 → 自定义 / OpenAI 兼容”：

| 字段 | 填写内容 |
| --- | --- |
| 自定义端点 / Base URL | `http://127.0.0.1:8788/v1` |
| API Key | `sk-local`，本机接口不校验此字段 |
| 模型 | `gemini-web` |
| 流式传输 | 支持 SSE，也可以关闭 |

插件在**酒馆进程内**自动监听本机回环端口 8788。该端口供酒馆服务端请求，远程访问酒馆时也填写此本机地址。它与 Chrome 的 9222 调试端口不同。

不要将 `/api/plugins/gemini-web-bridge` 填为模型端点：酒馆自身路由受登录和 CSRF 保护，普通模型客户端不会携带这些会话凭据。兼容接口使用插件管理的本机监听器，无需更改酒馆的 CSRF 设置。

**Gemini 正文会等网页生成结束并停稳后，通过 SSE 一次返回。** 网页可能改写已经显示的文字，等待稳定可以避免重复和错误拼接；echo 自测后端仍逐段发送。

## 配置

编辑插件目录的 `config.json` 后重启酒馆。也可设置 `GEMINI_BRIDGE_CONFIG` 环境变量指定独立配置文件，便于更新插件时保留个人配置。

| 键 | 默认值 | 作用 |
| --- | --- | --- |
| `host` | `127.0.0.1` | 只支持本机回环地址，也可用 `::1` |
| `port` | `8788` | 插件的本机兼容 API 端口 |
| `backend` | `gemini-cdp` | 真实 Gemini；改为 `echo` 可先自测连接 |
| `modelId` | `gemini-web` | 暴露给客户端的模型名，不切换网页上的实际模型 |
| `contextMode` | `full` | 将酒馆完整 messages 渲染成单条提示词 |
| `nameForAssistant` | `角色` | 提示词中的助手称呼 |
| `cdpPort` | `9222` | Chrome 调试端口，需与 Chrome 启动参数一致 |
| `newChatEachRequest` | `true` | 每次打开新会话，避免重复追加历史 |
| `maxWaitMs` | `180000` | 单次请求的等待上限，超时返回错误并尝试停止生成 |
| `settleMs` | `1200` | 生成结束后文字需保持稳定的时长 |
| `debug` | `false` | 打印完整提示词，可能包含角色卡和对话内容 |

推荐 `full` + `newChatEachRequest: true`，酒馆掌握完整上下文，重新生成不会重复追加历史。

如果选择 `lastUser`，请同时设置 `newChatEachRequest: false`：仅发送最后一条用户消息，让网页保留上下文。此模式不会同步酒馆中删除、编辑、切换聊天和重新生成对历史的修改，也不适合多个聊天共享同一个网页会话。

桥接按顺序执行请求。停止生成或客户端断开时会取消任务；尚未执行的任务会被跳过，活动任务完成停止清理后再放行下一项。所有使用者共享这一个本机 Chrome 会话。

只支持文本输入。temperature、top_p、max_tokens 等参数不能直接控制消费级网页，模型和相关选项请在 Gemini 网页中设置。usage 中的 token 数是估算值。

## 状态与排查

- 在已登录的酒馆网页打开 `/api/plugins/gemini-web-bridge/status`，查看插件是否加载及实际模型端点。
- 打开 `http://127.0.0.1:8788/health`，检查本机监听器；这里的 ok 仅表示接口存活，不代表 Google 登录有效。
- 报“端口已占用”：关闭旧的独立桥接服务，或更改插件 `port`，并同步更新酒馆中的 Base URL。
- 报“连不上 Chrome 调试端口”：运行 `start-chrome-debug.bat`，确认窗口仍开启。普通 Chrome 窗口没有开放该端口。
- 报登录失效、输入框找不到、超时：先在调试 Chrome 内手动确认 Gemini 可用，再运行 `node tools/inspect-gemini.mjs` 检查选择器。
- 网页改版时，候选选择器集中在 `backends/gemini-cdp.mjs` 的 `SEL` 中。
- 插件针对 SillyTavern 的 Node.js 插件接口；其他酒馆实现需支持相同的插件加载方式。

## 开发与自测

```powershell
npm install
npm test
```

开发测试用 Express 验证官方路由契约；它是 devDependency，插件运行时使用酒馆传入的 router，无需安装额外依赖。

保留可选的独立诊断入口：

```powershell
node server.mjs --backend echo --port 8788
node test/smoke.mjs
node test/page-scripts.mjs
```

真实独立诊断使用 `node server.mjs --backend gemini-cdp`。不要与占用相同端口的酒馆插件同时运行。

## 文件

- `index.mjs`：酒馆插件的 info / init / exit 生命周期。
- `lib/service.mjs`：配置、兼容 API 监听器与关闭清理。
- `lib/bridge.mjs`：OpenAI 兼容接口、校验、SSE、队列与取消。
- `lib/cdp.mjs`：带连接检查、超时和取消的 CDP 客户端。
- `backends/gemini-cdp.mjs`：页面等待、新回答识别与生成控制。
- `server.mjs`：可选独立诊断入口。
