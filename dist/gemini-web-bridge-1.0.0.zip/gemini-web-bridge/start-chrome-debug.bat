@echo off
chcp 65001 >nul
rem 启动一个带调试端口的 Chrome，供桥接服务通过 CDP 接管。
rem 要用你自己的 Google 登录态，就首次在这个窗口里登录一次，profile 会保存在下面这个目录。
set "CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" (
  echo [x] 找不到 Chrome，请手动修改脚本里的 CHROME 路径。
  pause
  exit /b 1
)
set "PROFILE=%LOCALAPPDATA%\gemini-bridge-chrome"
echo [i] Chrome profile: %PROFILE%
echo [i] 如果这是第一次运行，请在弹出的窗口里登录 Google 账号并打开一次 Gemini。
start "" "%CHROME%" --remote-debugging-port=9222 --user-data-dir="%PROFILE%" --no-first-run --no-default-browser-check "https://gemini.google.com/app"
echo [i] Chrome 已启动。保持它开着，然后启动或重启酒馆以加载插件。
